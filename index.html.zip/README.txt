Creator Anime One CAOFAMS Website

Buka index.html di browser.

Ganti foto admin dengan menambahkan file:
assets/admin/admin01.jpg
assets/admin/admin02.jpg
...
assets/admin/admin17.jpg

Perubahan terbaru:
- Logo CAO dipasang di bagian kanan section Gas Join.
- Hero card: Gen 2 kiri, Gen 1 tengah, Gen 3 kanan Coming Soon.
- Daftar Generasi: Gen 2 kiri, Gen 1 tengah, Gen 3 Coming Soon.
